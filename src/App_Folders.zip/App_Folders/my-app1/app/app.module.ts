import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SetbackgroundColor } from './directive_folder/custome.directive';

import { ServersComponent } from './servers/servers.component';

import { RoutingComponent } from './routing/routing.component';
import { ProductViewComponent } from './product-view/product-view.component';
import { SearchComponent } from './search/search.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { FormsComponent } from './forms/forms.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HoverDirective } from './servers/hover.directive';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';

import { HttpClientModule } from  '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { EditableTableModule } from 'ng-editable-table';
import { EditableTableModule } from 'ng-editable-table/editable-table/editable-table.module';
import { UserComponent } from './user/user.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { DialogBoxComponent } from './dialog-box/dialog-box.component';
import { AgGridModule } from 'ag-grid-angular';

@NgModule({
  declarations: [
    AppComponent,
    SetbackgroundColor,
    ServersComponent,
    RoutingComponent,
    ProductViewComponent,
    SearchComponent,
    PageNotFoundComponent,
    FormsComponent,
    HoverDirective,
    RegistrationComponent,
    LoginComponent,
    DashboardComponent,
    UserComponent,
    DialogBoxComponent
   
  ],
  imports: [
    BrowserModule,
    HttpClientModule ,
    AppRoutingModule,
    FormsModule,
    MatTableModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatInputModule,
    ReactiveFormsModule,
       BrowserAnimationsModule,
       AgGridModule,
    
  ],
  providers: [  ],
 
  bootstrap: [AppComponent]
})
export class AppModule { }
