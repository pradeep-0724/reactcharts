import { Directive, ElementRef } from "@angular/core";

@Directive({
    selector:'[SetbackgroundColor]'
})
export class SetbackgroundColor{
    constructor(element:ElementRef){
   element.nativeElement.style.backgroundColor="lightgreen";

    }
}
