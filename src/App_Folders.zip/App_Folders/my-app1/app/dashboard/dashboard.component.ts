import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { CellClickedEvent, ColDef, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  formdata: any[] = [];
  dt: undefined;
  status: boolean | undefined;
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {
      console.log(res);
      this.formdata = res;
      console.log(this.formdata);
    })
  }
  deleteRec(e: any) {
    if(confirm("are sure to delete this",)){
      console.log("jojjoojih");
      this.http.delete<any>(`http://localhost:3000/formdata/${e}`).subscribe(res => {

      console.log(res);
    })
    for (let ele of this.formdata) {
      if (ele.id === e) {
        const id = this.formdata.indexOf(ele)
        this.formdata.splice(id, 1)
      }
    }
    }
    console.log(e);
    

  }

  activeRec(e: any,id:number) {
    console.log(e.target.checked,id);
    if(e.target.checked==true){
      this.status=true
    }else{
      this.status=false

    }
    let statusm = {
      "status": this.status
    }

    this.http.patch<any>(`http://localhost:3000/formdata/${id}`, statusm).subscribe(res => {

      console.log(res);
    })

  }
  rowChange(e:any,id:number){
    let statusm = {
      "firstname":e.target.value
    }
    console.log(e.target.value);
    this.http.patch<any>(`http://localhost:3000/formdata/${id}`, statusm).subscribe(res => {

      console.log(res);
    })
  }
}