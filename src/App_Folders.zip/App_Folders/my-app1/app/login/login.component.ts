import { HttpClient } from '@angular/common/http';
import { Component, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  checkoutForm: FormGroup|any;
  forgotPswdPage: FormGroup |any;
  storedata: any;
  checkform = []
  nPassword = ''
  jsondata: any;
  formdata: any[] = [];
  statusmsg: string = ''
  flag: boolean | undefined;
  isVisible = true;
  useremails: string[] = [];
  constructor(
    private formbuilder: FormBuilder, private rte: Router, private http: HttpClient) {
    this.checkoutForm = this.formbuilder.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(3)]],
    });
    this.forgotPswdPage = this.formbuilder.group({
      femail: ['', [Validators.required]],
      fpassword: ['', [Validators.required, Validators.pattern(/^(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[A-Z])(?=.*[a-z])[a-zA-Z0-9!@#$%^&*]{6,16}$/)]],
      fcpassword: ['', [Validators.required]]
    })

  }
  ngOnDestroy(): void {
    //  localStorage.clear()
  }

  loginFunc() {
    this.statusmsg='';
    console.log(this.checkoutForm.value.email);
    if (this.useremails.includes(this.checkoutForm.value.email)) {
      for (let ele of this.formdata) {

        if (ele.email == this.checkoutForm.value.email && ele.password == this.checkoutForm.value.password) {
          if (ele.status === true) {
            alert('Your account has been deactivated by Admin, and you cannot reset the password')
          } else {
            console.log("success");
            console.log(ele.email);
            console.log(ele.password);
            console.log(this.checkoutForm.value.email);
            console.log(this.checkoutForm.value.password);

            this.statusmsg = 'Successfully Logged In';
            console.log(this.statusmsg);

            this.rte.navigate(['users'])

            localStorage.setItem('userData', this.checkoutForm.value.email)
          }
        }
        else{
          this.statusmsg='Email and Password not matched'
        }
       
      }
    }
    else {
      this.statusmsg = 'Invalid User'
      console.log(this.statusmsg);
      console.log("fail");
    }

  }
  history() {
    window.history.go(-1)
  }

  ngOnInit(): void {

    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {

      this.formdata = res;
      console.log(this.formdata);
      this.formdata.map((ele) => {
        this.useremails.push(ele.email)
      })
      console.log(this.useremails);



    })
  }
  ForgotPswdSubmitPage() {
    console.log(this.forgotPswdPage.value);
    if (this.useremails.includes(this.forgotPswdPage.value.femail)) {
      for (let ele of this.formdata) {
        if (ele.email === this.forgotPswdPage.value.femail) {
          if (ele.status == true) {
            alert(`Admin Has Restricted Your Account, You Can't Reset Your Password`)
          }
          else {
            let password = {
              "password": this.forgotPswdPage.value.fpassword
            }
            this.http.patch<any>(`http://localhost:3000/formdata/${ele.id}`, password).subscribe(res => {

              console.log(res);

            })
            setTimeout(() => {
              this.forgotPswdPage.reset()
              window.history.go(-1)

            }, 1000);
          }
        }

      }
    }
    else {
      alert('No Account Found With The Given EmailId');
      this.forgotPswdPage.reset()

    }

  }
  forgotPasswrd() {
    this.isVisible = false
    // const email = prompt('enter email');
    // const pswd = prompt('enter new password');

    // let password = {
    //   "password": pswd
    // }
    // for (let ele of this.formdata) {
    //   if (ele.status === true) {
    //     alert('Admin has restricted your accunt')
    //   }
    //   else if (ele.email === email) {
    //     this.http.patch<any>(`http://localhost:3000/formdata/${ele.id}`, password).subscribe(res => {

    //       console.log(res);
    //     })
    //   }
    // }
  }
}
