import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  logindetails(loginForm:NgForm){
    console.log(loginForm);
    console.log(loginForm.value.email);
    console.log(loginForm.value.password);
    
    
  }
}
