import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit, OnDestroy {
  formdata: any[] = [];
  user: any[] = [];
  data: any;
  constructor(private http: HttpClient, private rtr: Router) { }
  ngOnDestroy(): void {
    localStorage.clear()

  }

  ngOnInit(): void {
    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {

      this.formdata = res;
      console.log(this.formdata);
      this.data = localStorage.getItem('userData')
      for (let ele of this.formdata) {

        // console.log((ele.email));
        // console.log(typeof(this.data));
        if (ele.email === this.data) {

          this.user.push(ele)
          console.log(this.user);

        }

      }
    })


  }
  Logout() {
    this.rtr.navigate([''])
    localStorage.clear()
  }
  ChangePswd(){
    const pswd = prompt('enter new password');

    let password = {
      "password": pswd
    }
    for (let ele of this.formdata) {

      if (ele.email === this.data) {
        this.http.patch<any>(`http://localhost:3000/formdata/${ele.id}`, password).subscribe(res => {

          console.log(res);
        })
      }
    }
  }

}
