import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsComponent } from './forms/forms.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ProductViewComponent } from './product-view/product-view.component';
import { RegistrationComponent } from './registration/registration.component';
import { RoutingComponent } from './routing/routing.component';
import { SearchComponent } from './search/search.component';
import { ServersComponent } from './servers/servers.component';
import { UserGuardGuard } from './user-guard.guard';
import { UserComponent } from './user/user.component';

const routes: Routes = [
 
  {path:'login',component:LoginComponent,},
  {path:'',component:RegistrationComponent},
  {path:'register',component:RegistrationComponent },
  {path:'dashboard',component:DashboardComponent},
  {path:'users',component:UserComponent,canActivate:[UserGuardGuard]},
  {path: '**', component: RegistrationComponent}
  //  redirect to page
  
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule,]
})
export class AppRoutingModule { }
