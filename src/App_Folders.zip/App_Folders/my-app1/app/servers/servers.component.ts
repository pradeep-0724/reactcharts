import { Component, OnInit } from '@angular/core';
import { count } from 'rxjs';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})

export class ServersComponent implements OnInit {
  name:string="pradeep";
  id:number=209010;
  flag:boolean=true;
  profession: string= "web deveopment";
  counter:number=0
  colorName:string ='blue';
  skills=[
    {id:1,skill:"c"},
    {id:2,skill:"JS"},
    {id:3,skill:"REACT"},
    {id:4,skill:"ANGULAR"}
  ]
  clsname='one';
  clsname2='two';
 
  constructor() {}

  ngOnInit(): void {
   
  }

}

