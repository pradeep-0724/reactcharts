import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerform: FormGroup;

  education: string[] = ['B.Tech', 'M.Tech', 'M.Sc', 'B.Ed', 'B.Sc', 'MS']
  hobbies: string[] = ['Music', 'Movies', 'reading', 'Swimming', 'Dance', 'Singing', 'Seeping', 'Coding', 'Running', 'TV']
  formdata: any[] = [];
  statusmsg: string = '';
  useremails: string[] = []
  usernames: string[] = []
  constructor(
    private formbuilder: FormBuilder, private rtr: Router, private activroute: ActivatedRoute, private http: HttpClient) {

    this.registerform = this.formbuilder.group({
      firstname: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^([a-zA-Z ]{3,15})$/)]],
      username: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(7), Validators.pattern(/^(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[A-Z])(?=.*[a-z])[a-zA-Z0-9!@#$%^&*]{6,16}$/)]],
      cpassword: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern('[6-9]{1}[0-9]{9}')]],
      gender: [''],

      //   email:['',[Validators.required, Validators.email]],
      //  password:['',[Validators.required,Validators.minLength(3)]],
    })
  }


  ngOnInit(): void {
    console.log(this.rtr.url);
    console.log(window.location.href);
    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {
      console.log(res);
      this.formdata = res;
      console.log(this.formdata);

    })


    console.log("hhhih");

  }
  SubmitData() {
    this.http.post('http://localhost:3002/angulardata',this.registerform.value).subscribe(res=>{
      console.log(res);
      
    })
    this.statusmsg='';
    this.registerform.value.status = false
    for (let ele of this.formdata) {
      this.useremails.push(ele.email);
      this.usernames.push(ele.username);

    }
    if (this.useremails.includes(this.registerform.value.email) || this.usernames.includes(this.registerform.value.username)) {
      alert('Email or Username already exists');
      this.statusmsg = 'Already email exists';
    } else {

      this.http.post<any>('http://localhost:3000/formdata', this.registerform.value).subscribe(res => {

        console.log(res);
      })
      this.statusmsg = 'User Registered Successfully';
      this.rtr.navigate(['login'])

    }
    console.log(this.useremails);


  }
  fileUpload(event:any){
    console.log(event.target.files[0].name);
    var myFormData = new FormData();
    const headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');
    myFormData.append('image', event.target.files[0].name);
    /* Image Post Request */
    this.http.post('../images', myFormData, {
    headers: headers
    }).subscribe(data => {
     //Check success message
     console.log(data);
    });  
  }




}





