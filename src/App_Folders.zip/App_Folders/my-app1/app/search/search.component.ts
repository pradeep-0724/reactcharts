import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
@Input() inputData:any;

  queryCountry='';
  queryTag='';
  querystatus=''
// queryparams
  constructor(private activatedRoute:ActivatedRoute) { 
    this.activatedRoute.queryParams.subscribe((data)=>{
      console.log(data);
      this.queryCountry= data['country'];
      this.queryTag=data['tag'];
      this.querystatus=data['status']

    })
  }
  
  ngOnInit(): void {
    console.log(this.inputData);
    
  }

}
function value(value: any) {
  throw new Error('Function not implemented.');
}

function hiii(value: (value: any) => void, hiii: any) {
  throw new Error('Function not implemented.');
}

function jvj(value: (value: any) => void, jvj: any) {
  throw new Error('Function not implemented.');
}

