import { Component, EventEmitter, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-lifecycles',
  templateUrl: './lifecycles.component.html',
  styleUrls: ['./lifecycles.component.css']
})
export class LifecyclesComponent implements OnChanges,OnInit {
@Output() inputval=new EventEmitter<string>()
mins=0
hours=0
secs=0
interval:any;
  constructor() { 
    console.log('lifecycle constructor called')
    // constructor is not a lifecycle hook .it is a method which gets invoked whenever
    //  a class is instantiated
    //  by the time constructor is called input properties are not updaetd and not available to use
  }
  ngOnChanges(change:SimpleChanges): void {
    console.log('lifecycle onchanges called')

  }
// NgOniNit >>>> will be invoked when the component has initialsed
//  this hook will be called only after 1st ngOnChanges
  ngOnInit(): void {
    console.log('lifecycle ngonit called')

  }
  
  timer(){
    console.log('button is clicked')
   
    this.interval=setInterval(()=>{
      this.secs++
      if(this.secs>=10){
        console.log(this.secs)
        this.mins=this.mins+1
        this.secs=0
      }
      if(this.mins>2){
        this.hours++
        this.mins=0
        
      }
    },1000)
    
  }
 starttimer(){
  this.timer()
   
 }
  stoptimer(){
    console.log('stop clickeds')
    clearInterval(this.interval)
    
  
   
  }
addinput(inputval: any){
  console.log('devis')
  this.inputval.emit(inputval.value)
  // this.inputval=inputval.value
  console.log(this.inputval)
  inputval.value=''

}
}
