import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  storedata:any
  constructor( private store:Store<{data:{email:string,password:string}}>) { }

  ngOnInit(): void {
  }
  getdata(){
    this.store.select('data').subscribe((ele)=>{
      this.storedata=ele
      console.log(this.storedata);
      
    })
  }
}
