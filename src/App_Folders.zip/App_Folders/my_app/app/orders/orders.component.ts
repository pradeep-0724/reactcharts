import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { elementAt } from 'rxjs';
import { cartdecreaseFun, cartFun, counterFun, loginFun, logoutFun, removeitem } from '../store/action/actions';
import { UsersService } from '../Users/users.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  productList1: any[] = []
  productList: any[] = []
  ids: any;
  quantity: number = 1
  quant = 1
  flag = false;
  price: number =1;
  constructor(private userserv: UsersService, private rte: Router, private store: Store<{ data: { email: string, password: string } }>) { }

  ngOnInit(): void {
    this.productList1 = this.userserv.sendselectproduct()
    this.ids = this.userserv.sendproductid()
    // console.log(this.productList1);
    // console.log(this.ids);

    for (let ele of this.ids) {
      // console.log(ele);
      this.productList.push(this.productList1[ele])
      // console.log(this.productList);
      // console.log(this.productList[0].id);
    }

    console.log(this.productList," select products");
    for (let ele of this.productList) {
      console.log(ele);
    }
  }

  goback() {
    window.history.go(-1)
  }
  logout() {
    this.store.dispatch(logoutFun())
    this.rte.navigate(['checkout'])

  }
  add(pid: number) {
    console.log(pid,"id");
    console.log(this.productList[pid],"product");
    for(let ele of this.productList){
      if(ele.id==pid){
        ele.quantity =ele.quantity + 1;
         this.price = ele.cost;
         
       ele.displaycost=this.price *  ele.quantity
       this.store.dispatch(cartFun())

        // this.userserv.appCounter=this.userserv.appCounter+1
      }
    }
      
  }
  remove(pid: number) {
    for(let ele of this.productList){
      if(ele.id==pid){
        if(ele.quantity>=2){
          ele.quantity =ele.quantity - 1
          this.price = ele.cost;
          ele.displaycost=this.price *  ele.quantity
          this.store.dispatch(cartdecreaseFun())
          // this.userserv.appCounter=this.userserv.appCounter-1
        }
      }
    }
  }
  deleteitem(index:number){
    for(let ele of this.productList){
      
      if(index==ele.id){
       const reindex=this.productList.indexOf(ele)
       console.log(reindex,'index');
       
       console.log("produtlist",this.productList);
        this.productList.splice(reindex,1)
       console.log("produtlist",this.productList);
      this.store.dispatch(removeitem({value:ele.quantity}))
// this.userserv.appCounter=this.userserv.appCounter-ele.quantity
      }
    }
   
   
  }
}

