import { createAction, props } from "@ngrx/store";

export const loginFun=createAction('loginFun',props<{value1:any,value2:any}>());
export const registerFun=createAction('registerFun',props<{regval:any}>())
export const logoutFun= createAction('logoutFun')
export const counterFun=createAction('counerFun',props<{value:number}>())
export const cartFun=createAction('cartFun')
export const cartdecreaseFun=createAction('cartdecreaseFun')
export const removeitem=createAction('removeitem',props<{value:number}>())

// ,props<{value:object}>()