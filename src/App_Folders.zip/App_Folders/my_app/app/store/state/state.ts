export  const initialState={
        email:'',
        password:'',
        fname:'',
        lname:'',
        usermail:'',
        mobilenum:'',
        appCounter:0
}
