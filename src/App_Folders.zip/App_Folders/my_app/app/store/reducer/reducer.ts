import { state } from "@angular/animations"
import { createReducer, on } from "@ngrx/store"
import { cartdecreaseFun, cartFun, counterFun, loginFun, logoutFun, registerFun, removeitem } from "../action/actions"
import { initialState } from "../state/state"


const _FormReducer = createReducer(initialState,
    on(loginFun, (state, action) => {
        console.log(typeof (action));
        console.log(action.type);
        console.log(action.value1);


        //    let email=action.value1
        //    let password=action.value2
        //    let ar=[]
        //    ar[0]=action.value
        //    console.log(ar);
        //    ar.map((ele)=>{
        //        console.log(ele.password);
        //    })
        return {
            ...state,
            ...{ email: action.value1, password: action.value2 }

        }
    }),


    on(registerFun, (state, action) => {
        return {
            ...state,
            ...{
                fname: action.regval.firstname,
                lname: action.regval.lastname,
                usermail: action.regval.email,
                mobilenum: action.regval.mobile
            }



        }

    }),
    on(logoutFun, (state) => {
        return {
            ...state,
            email:'',
            password:'',
            fname:'',
            lname:'',
            usermail:'',
            mobilenum:''
        }
    }),
    on(counterFun,(state,action)=>{
        console.log(action);
        
        return {
            ...state,
            appCounter:action.value+state.appCounter
        }
    }),
    on(cartFun,(state)=>{
       
        
        return {
            ...state,
            appCounter:state.appCounter+1
        }
    }),
    on(cartdecreaseFun,(state)=>{
       
        
        return {
            ...state,
            appCounter:state.appCounter-1
        }
    }),
    on(removeitem,(state,action)=>{
       
        
        return {
            ...state,
            appCounter:state.appCounter-action.value
        }
    }),

)







export function FormReducer(state = initialState, action: any) {
    return _FormReducer(state, action)
}

