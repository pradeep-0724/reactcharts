import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LogoutGuard implements CanActivate {
  storedata:any
  constructor(private store:Store<{data:{email:string,password:string}}>){
    
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      this.store.select('data').subscribe((ele: any)=>{
        this.storedata=ele
        console.log(this.storedata.email);
      })
      if(this.storedata.email=='' ){
        return false
      }
      else{
        return true;
      }
  }
  }
