import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { elementAt } from 'rxjs';
import { counterFun, logoutFun } from '../store/action/actions';
import { UsersService } from '../Users/users.service';

@Component({
  selector: 'app-views',
  templateUrl: './views.component.html',
  styleUrls: ['./views.component.css']
})
export class ViewsComponent implements OnInit {
  paramquery = ''
  color: string | undefined
  public task: any;
  ind:any;
  storedata:any
  counter:number[] =[];
 productList:any=[]
 count=0;
  public items: string[] =[];
  constructor(private activeroute: ActivatedRoute, private userserv:UsersService,private rtr: Router, private store:Store<{data:{data:object}}>) {
    this.activeroute.params.subscribe((data) => {
      console.log(data);
      this.paramquery = data['id']

    })

  }


  ngOnInit(): void {
    this.productList=this.userserv.sendproducts()
    // console.log(this.productList);
    
   console.log(this.userserv.productList);
   this.store.select('data').subscribe((ele: any)=>{
    this.storedata=ele
    // console.log(this.storedata);
 
    
  })
   
  }
  changehandler(color: any) {
    this.color = color;
    console.log('buttons is clicked', color)
  }
  adtask() {
    console.log('button is clicked')
    if (this.task == '') {
    }
    else {
        this.items?.push(this.task);
        this.task = '';
        console.log(this.items)
    }
  }
  deletask(ind:any){
    console.log('delete clickedds')
    this.items.splice(this.ind,1)
  }
  addtocart(id: any){
    console.log(id)
    this.count=this.count+1
    console.log(this.productList[id]);
    // this.rtr.navigate(['selectproduct'],{queryParams:{id1:id}})
    // this.counter.push(id)
    this.userserv.id?.push(id)
    // console.log(this.counter);
    for(let ele of this.productList){
    console.log(ele,"product");
      if(ele.id==id){
        this.store.dispatch(counterFun({value:ele.quantity}))
        // loginFun({value1:this.checkoutForm.value.email,value2:this.checkoutForm.value.password}))
        // this.userserv.appCounter=this.userserv.appCounter+ele.quantity

      }
    }
    // console.log("counter ",this.userserv.appCounter);
    
    
    
  }
  detailspage(id:number){
this.userserv.detailsProduct(id)
this.rtr.navigate(['product'])
  }
  add(pid: number) {
    console.log(pid,"id");
    
    for(let ele of this.productList){
      if(ele.id===pid){
    console.log(ele,"product");

        ele.quantity =ele.quantity + 1;
        
        // this.userserv.appCounter=this.userserv.appCounter+ele.quantity
      }
    }
   
      
  }
  remove(pid: number) {
    for(let ele of this.productList){
      if(ele.id==pid){
        if(ele.quantity>=2){
          ele.quantity =ele.quantity - 1
         
         
          // this.userserv.appCounter=this.userserv.appCounter-ele.quantity
        }
      }
    }
  }

  
 

}
