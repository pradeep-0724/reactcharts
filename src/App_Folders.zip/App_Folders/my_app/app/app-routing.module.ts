import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from './admin-guard.guard';
import { AppComponent } from './app.component';

import { CheckoutComponent } from './login/login.component';
import { ChildComponent } from './child/child.component';
import { FormsComponent } from './forms/forms.component';
import { LogoutGuard } from './logout.guard';
import { NavbarComponent } from './navbar/navbar.component';
import { OrdersComponent } from './orders/orders.component';
import { ParamRoutingComponent } from './param-routing/param-routing.component';
import { ProductsComponent } from './products/products.component';
import { RegistrationComponent } from './registration/registration.component';
import { SelectProductComponent } from './select-product/select-product.component';
import { ViewsComponent } from './views/views.component';

const routes: Routes = [
  {path:'', component:CheckoutComponent},
  {path:'views',component:ViewsComponent},
  
 
  // canActivate:[AdminGuardGuard]
  {path:'selectproduct',component:SelectProductComponent},
  {path:'app',component:AppComponent},
  {path:'orders',component:OrdersComponent},
  // {path:'**',component:CheckoutComponent},
  // {path:'products',component:ProductsComponent},
  {path:'register',component:RegistrationComponent},
  {path:'login',component:CheckoutComponent},
  { path: 'product', loadChildren: () => import('./product/product.module').then(m => m.ProductModule) },
  
  // { path: 'orders', loadChildren: () => import('./orders/orders.module').then(m => m.OrdersModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
