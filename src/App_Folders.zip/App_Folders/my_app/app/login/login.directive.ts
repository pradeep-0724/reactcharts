import { Directive, HostListener, OnInit } from '@angular/core';

@Directive({
  selector: '[alphabet]',
})
export class AlphabetsComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  @HostListener('keypress',['$event']) onkepress(event: { key: any; }){
    let regex= /^[a-zA-Z]*$/g;
    let v=event.key
    
    if(regex.test(v)){
      console.log(event.key,"value")
      return true
    }
    else{
      return false
    }
  }
}
