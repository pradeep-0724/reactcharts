import { HttpClient } from '@angular/common/http';
import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import {FormGroup,FormControl,FormBuilder, Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { loginFun } from '../store/action/actions';
import { UsersService } from '../Users/users.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class CheckoutComponent implements OnInit ,OnChanges{
  checkoutForm:  FormGroup |any;
  storedata:any;
  checkform=[]
  jsondata:any;
  constructor(  private store:Store<{data:{email:string,password:string}}>,
    private formbuilder: FormBuilder,private rte:Router,private userserv:UsersService,private http:HttpClient) { 
   this.checkoutForm=formbuilder.group({
     email:['',[Validators.required, Validators.minLength(5)]],
     password:['',[Validators.required,Validators.minLength(3)]],
    
    
   });
  }

  details(){
  this.checkform=  this.checkoutForm.value
    console.log(this.checkform);
    console.log(typeof(this.checkform));
    this.store.dispatch(loginFun({value1:this.checkoutForm.value.email,value2:this.checkoutForm.value.password}))
    // console.log("hi");
    // console.log(this.checkoutForm);
    // console.log(this.checkoutForm.value);
    // console.log(this.checkoutForm.value.email);
    // localStorage.setItem("email",this.checkoutForm.value.email)
    // localStorage.setItem("password",this.checkoutForm.value.password)
this.http.get<any>('http://localhost:3000/formdata').subscribe(res=>{
  console.log(res);
  
})
  this.rte.navigate(['views'])
  // localStorage.setItem('check',JSON.stringify(this.checkoutForm.value))
    
    
  }
  ngOnChanges(): void {
    console.log("onchanges works");
    
  
}
  
  ngOnInit(): void {
    this.store.select('data').subscribe((ele: any)=>{
      this.storedata=ele
      console.log(this.storedata.email);
    })
   
    
  }
getdata(){
  console.log("getdata");
  
}
signup(){
  this.rte.navigate(['register'])
}
 
}
