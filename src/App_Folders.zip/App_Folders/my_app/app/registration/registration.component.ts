import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { loginFun, registerFun } from '../store/action/actions';
import { UsersService } from '../Users/users.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerform:FormGroup;
  registerdata: any;
  flag:any;
  agent:any;
  storedata:any;
  constructor(  private store:Store<{data:{data:object}}>,
    private formbuilder:FormBuilder, private rtr:Router,private userServ:UsersService, private activroute:ActivatedRoute,private http:HttpClient) { 
  
    this.registerform=formbuilder.group({
      firstname:['',[Validators.required,Validators.minLength(3),Validators.pattern(/^([a-zA-Z ]{3,15})$/)]],
      lastname:['',[Validators.required,Validators.minLength(5)]],
      email:['',[Validators.required,Validators.email]],
      password:['',[Validators.required,Validators.minLength(7),Validators.pattern(/^(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[A-Z])(?=.*[a-z])[a-zA-Z0-9!@#$%^&*]{6,16}$/)]],
      cpassword:['',Validators.required],
      mobile:['',[Validators.required, Validators.pattern('[6-9]{1}[0-9]{9}')]],
      gender:[''],
      send_newsletter:[''],
      agree:['']
    //   email:['',[Validators.required, Validators.email]],
    //  password:['',[Validators.required,Validators.minLength(3)]],
    })
  }
  
   
  ngOnInit(): void {
    console.log(this.rtr.url);
    console.log( window.location.href);
    this.store.select('data').subscribe((ele: any)=>{
      this.storedata=ele
      console.log(this.storedata);
   
      
    })
    if(this.storedata.email==''){
      this.flag=false
    }
    else{
      this.flag=true
    }
  
  }
  submitData(){
    console.log(this.registerform.value.mobile);
    console.log(this.registerform.value.gender);
    console.log(this.registerform.value.agree);
    console.log(this.registerform.value.send_newsletter);

    this.http.post<any>('http://localhost:3000/formdata',this.registerform.value).subscribe(res=>{
      console.log(res);
      
    })
    this.store.dispatch(registerFun({regval:this.registerform.value}))
    // this.rtr.navigate(['products'])
    this.rtr.navigate(['views'])
    
    
  //  this.agent= this.userServ.agent
  //  this.agent=new Observable((oberver)=>{
  //    try{
  //      oberver.next(this.registerform.value)
  //    }
  //    catch(err){
  //      console.log(err);
       
  //    }
  //  })
    // this.store.dispatch(loginFun())
    // console.log("hi");
    //  this.registerdata=this.registerform.value
    // console.log(this.registerform.firstname);
    // localStorage.setItem('data',JSON.stringify(this.registerform.value))
    // localStorage.setItem("firstname",this.registerform.value.firstname)
    // localStorage.setItem("lastname",this.registerform.value.lastname)
    // localStorage.setItem("mobile",this.registerform.value.mobile)
    // this.userServ.setregistartionfromdata(this.registerdata)
    
  
    // return this.registerform.value
  
   
  }
  goback(){
    window.history.go(-1)
  }
  
  

}

