import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { UsersService } from '../Users/users.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  values: any;
  data:any
  flag:any
  formdata: any;
  obsd:any;
  productList:any[]=[];
  
  storedata:any
 
  constructor( private rtr:Router, private userserv:UsersService, private store:Store<{data:{data:object}}>) { 
    
  }
 

  ngOnInit(){
    this.productList.push(this.userserv.senddetailsProduct())
    // console.log(localStorage.getItem(('data')))
    // this.data=this.userserv.registartionfromdata()
    // console.log("form data from products page",this.data);
    // this.store.select('data').subscribe((ele: any)=>{
    //   this.storedata=ele
    //   console.log(this.storedata);
   
      
    // })
  
  }
  logout(){
   
   console.log(this.obsd);
   
   
    localStorage.clear()
    this.rtr.navigate([''])
      
   
  }

}
