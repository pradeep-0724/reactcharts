import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-mgment',
  templateUrl: './store-mgment.component.html',
  styleUrls: ['./store-mgment.component.css']
})
export class StoreMgmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
