import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreMgmentComponent } from './store-mgment.component';

describe('StoreMgmentComponent', () => {
  let component: StoreMgmentComponent;
  let fixture: ComponentFixture<StoreMgmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoreMgmentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StoreMgmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
