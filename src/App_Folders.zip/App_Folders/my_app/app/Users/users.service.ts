import { HttpClient } from '@angular/common/http';
import { enableProdMode, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
arData:any[] | undefined
obsdata:any;
agent: Observable<string> | undefined;
id:number[] =[] ;
details:any;
appCounter=0
productList=[
  {id:0,pname:"shirt",cost:600,displaycost:600, size:'M',material:'cotton',color:'blue',rating:4/5,likes:100,src:'assets/images/shirt.jpg' ,quantity:1},
  {id:1,pname:"short",cost:250 ,displaycost:600,size:'S',material:'polyster',color:'black',rating:3/5,likes:300,src:'assets/images/short.jpg',quantity:1},
  {id:2,pname:"shoes",cost:900,displaycost:600,size:'8',material:'plastic',color:'brown',rating:4/5,likes:300,src:'assets/images/shoes.jpg',quantity:1},
  {id:3,pname:"track-pant",size:'L',displaycost:600,cost:400,material:'cotton',color:'black',rating:4.5/5,likes:400,src:'assets/images/trackpant.jpg',quantity:1},
  {id:4,pname:"shirt",cost:700,size:'L',displaycost:600,material:'pure -cotton',color:'purple',rating:4/5,likes:800,src:'assets/images/shirt_grey.jpg',quantity:1},
  {id:5,pname:"sneakers",cost:900,size:'9',displaycost:600,material:'leather',color:'brown',rating:4/5,likes:100,src:'assets/images/sneakers.jpg',quantity:1},

]
  constructor(  private http:HttpClient) {
  
   
  }
 
  sendproducts(){
    return this.productList
  }
//   setproductid(ele:number){
// this.id=ele
//   }
sendcounter(){
  return this.appCounter
}
  sendselectproduct(){
    return this.productList;
  }
  sendproductid(){
    // console.log(this.id,"from services id");
    
    return this.id
  }

  detailsProduct(ele: any){
this.details=ele
  }
  senddetailsProduct(){
    return this.productList[this.details]
  }
 getAllUsers() {
   return this.http.get('https://jsonplaceholder.typicode.com/users')
   
 }
 setregistartionfromdata(data: number[]){
   this.arData=data
  //  console.log(this.arData);
   
 }
 registartionfromdata(){
   return this.arData
 }
}
// agent: Observable<string> | undefined;
   
// this.agent = new Observable((observer) => {
//   try {
//     observer.next('pradeep')
//     observer.next('sunu')
//   }
//   catch (e) {
//     observer.error(e)
//   }
// })
// this.agent.subscribe((data) => {
//   console.log(data)
// })
