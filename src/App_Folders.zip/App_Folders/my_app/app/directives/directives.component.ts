import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  val=3
  users=[
    {id:1,name:"pradeep"},
    {id:2,name:"praveen"},
    {id:3,name:"nagendra"},
    {id:4,name:"ramesh"}
  ]
  flag: boolean | undefined ;
toggle(){
  this.flag=!this.flag
}
}
