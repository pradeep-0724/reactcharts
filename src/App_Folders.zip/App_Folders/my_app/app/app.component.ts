import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, observable } from 'rxjs';
import { logoutFun } from './store/action/actions';
import { UsersService } from './Users/users.service';

// >>>>>>>>>>>>>>>>

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  title = 'my-app';
  input:HTMLElement | undefined
  Name: '' | undefined
  flag: boolean | undefined;
  flag2: boolean = false;
  users: any;
  storedata: any
  lfcinput: any
  count: number = 0
  lastname: '' | undefined
  firstname: '' | undefined

  constructor(private activeroute: ActivatedRoute, private usersService: UsersService, private route: Router, private store: Store<{ data: { data: object } }>) {
    // console.log('app contructor called')

  }



  goback() {
    window.history.go(-1)
  }
  cart() {
    this.route.navigate(['orders'])
  }
  logout() {
    this.store.dispatch(logoutFun())
    this.route.navigate(['login'])
  }
  ngDoCheck(): void {
    this.count = this.usersService.sendcounter()
    this.store.select('data').subscribe((ele: any) => {
      this.storedata = ele
      this.firstname = ele.fname
      this.lastname = ele.lname
      // console.log(this.storedata, this.storedata.email, "store data");
      this.count = this.storedata.appCounter
    })
    if (this.storedata.email != '' || this.storedata.fname != '') {
      this.flag = true
      //  console.log("flag is ",this.flag);
    }
    else {
      this.flag = false
      //  console.log("flag is ",this.flag);
    }
    // if(this.storedata.email!=''){
    //  
    //   this.flag=true
    // }

    // console.log('app ngoninit called')
    // console.log(this.route.url);


    // if(this.route.url=='/'){
    //   this.flag=false  
    //   console.log("true");

    // }
    // else{
    //   console.log("false");
    //   this.flag=true
    // }
    // console.log( window.location.href);

    // const promise=new Promise((resolve)=>{
    //   console.log('promise working')
    //   setTimeout(() => {
    //     resolve('promise resolve is working')

    //   }, 1000);
    // })
    //   promise.then((result)=>console.log('promise working') )

    // const observable=new Observable(sub =>{
    //   console.log('observable call')
    //   let counter=0
    //   setTimeout(() => {
    //     counter=counter+1
    //     sub.next(counter)
    //   }, 1000);
    // })
    // observable.subscribe(result => console.log('subscriber from working'))
  }
  inputval(value: any) {
    this.lfcinput = value
    // console.log(this.lfcinput)
  }
  menuToggle() {
    this.flag2 = !this.flag2
    //  this.toggleMenu = document.getElementsByClassName('.menu')
    // this.toggleMenu.classList.toggle('active')
  }
  
}
