import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from '../Users/users.service';

@Component({
  selector: 'app-select-product',
  templateUrl: './select-product.component.html',
  styleUrls: ['./select-product.component.css']
})
export class SelectProductComponent implements OnInit {
selectproduct:any;
  constructor( private userserv:UsersService,private rtr:Router) { }

  ngOnInit(): void {
    this.selectproduct=this.userserv.sendselectproduct()
    console.log(this.selectproduct);
    
  }
  gotopage(){
    this.rtr.navigate(['orders'])
  }

}
