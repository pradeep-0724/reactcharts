import { Component, DoCheck, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit , OnDestroy,OnChanges,DoCheck{
counter=0
interval:any
inputVal: any;
@Input() 
childVar: any;

@Output() 
newvar=new EventEmitter<string>()

  constructor() {
    console.log("childcomponent constructor works");
    
   }
  ngOnChanges() {
    console.log("ngonchanges from child component ");
  }
  ngDoCheck() {
    console.log("do check is worked in child");
    
  }
  

  ngOnInit(): void {
    console.log("child compnent ngoninit");
   this.newvar.emit('this is from praveen decorator')
    // this.interval=setInterval(()=>{
    //   this.counter=this.counter+1
    //   console.log(this.counter);
      
    // },1000)
    
  }
  ngOnDestroy(): void {

    console.log("ngondestroyis called");
    // clearInterval(this.interval)
    
  }
}
