import { Directive, HostListener, OnInit } from '@angular/core';

@Directive({
  selector: '[appInput]',
})
export class Restrict implements OnInit {
  ngOnInit(): void {
    
  }
  // @HostListener('change',['$event'])  onchange(event : { target: any; }){
  //   console.log(event.target.value)
  // }
  //   @HostListener('change',['$event']) keypres(event) {
  //     console.log('key pressed',event.target.value);
  //   }
  @HostListener('keypress', ['$event'])
  onchange(event: any) {
    let v = event.target.value;
    let ar=['1','2','3','4','5','6','7','9','8','0']
   if(ar.includes(v)){
       console.log("matched");
       
   }
    // console.log(v)
    // let inputVal=document.getElementById('input').value;
    // /^([0-9]{1,15})$/;
    let regex = /^[0-9]*$/g;
    // if (v.match(regex)) {
    //   console.log('matech', v);
    //   return true

    // }
    // else{
    //   return false
    // }
    console.log('hi')
    for (let i = 0; i < v.length; i++) {
        if(ar.includes(v)){
            console.log("strig matched");
            
        }
    }
    console.log(v);
    if (regex.test(v)) {
      console.log('matched');
      return true;
    } else {
      return false;
    }
  }
}
