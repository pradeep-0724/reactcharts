import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminGuardGuard implements CanActivate {
  storedata:any
  constructor( private store:Store<{data:{email:string,password:string}}>){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean  {
      this.store.select('data').subscribe((ele: any)=>{
        this.storedata=ele
        console.log(this.storedata);
      })
      if(this.storedata.email !='' ||this.storedata.usermail !='' ){
        return true
      }
      else{
        return false;
      }
  }
  
}
