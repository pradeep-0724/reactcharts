import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-param-routing',
  templateUrl: './param-routing.component.html',
  styleUrls: ['./param-routing.component.css']
})
export class ParamRoutingComponent implements OnInit {
  
  // paramsqury:'' | undefined ;
id1:''|undefined
id2:'' | undefined;
  constructor(private activatedroute:ActivatedRoute) {
    this.activatedroute.queryParams.subscribe((data)=>{
      this.id1=data['id']
      console.log(this.id1);
      console.log(this.id2);
      
      this.id2=data['id2']
      
    })
   }

  ngOnInit(): void {
  }

}
