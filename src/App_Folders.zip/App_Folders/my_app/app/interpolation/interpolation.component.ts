import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interpolation',
  templateUrl: './interpolation.component.html',
  styleUrls: ['./interpolation.component.css']
})
export class InterpolationComponent implements OnInit {

  constructor() { }
  user='pradeep'
  colorName='blue'
  clsName='c1'
placeholder="enter name"
hrefval='www.google.com'
updatedlink="www.angular.io"
  ngOnInit(): void {
  }
  name=''
  flag=false
  count=0
  clickevent(){
   this.count=this.count+1
   console.log(this.count)
    console.log('button clicked')
    // alert('buttn is clicked'+ this. count)
  }
  mouseout(){
    console.log('moue out')
  }
  mouseenter(){
    console.log('mouse enterd')
  }
  mapped(){
    this.flag=!this.flag
  }
}
 