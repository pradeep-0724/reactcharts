import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { count, debounceTime, distinct, elementAt, first, from, fromEvent, interval, last, max, min, Observable, observable, of, skip } from 'rxjs';

@Component({
  selector: 'app-rxjs-observables',
  templateUrl: './rxjs-observables.component.html',
  styleUrls: ['./rxjs-observables.component.css']
})
export class RxjsObservablesComponent implements OnInit {
  
@ViewChild('button')
button:ElementRef | undefined
items=['pants','tracks','shoes','x']
orders:Observable<string> = from(this.items)
  
  constructor() { }

  ngOnInit(): void {
    this.orders.pipe(min()).subscribe((data)=>{
      // const seqnum=interval(1000)
      // seqnum.subscribe((num)=>{
          console.log(data)
        

        
      
    })
  }
  obserButton(){
   const btnobservable=fromEvent(this.button?.nativeElement,'click')
   btnobservable.subscribe((data)=>{
     console.log(data)
   })
  }

}

// <<<<<<<<<<<<
// agent: Observable<string> | undefined;
   
// this.agent = new Observable((observer) => {
//   try {
//     observer.next('pradeep')
//     observer.next('sunu')
//   }
//   catch (e) {
//     observer.error(e)
//   }
// })
// this.agent.subscribe((data) => {
//   console.log(data)
// })
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// <<<<<<<<<<<<<<< of operator
// studentsList=['pradeep','sunu','sadist']
//   students:Observable<string[]>=of(this.studentsList)
//   this.students.subscribe((data)=>{
//     console.log(data)
//   })  >>>>>>>>>>>>>>>>>>>>
