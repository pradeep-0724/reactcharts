import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Observable, observable } from 'rxjs';

@Component({
  selector: 'app-change-parent',
  templateUrl: './change-parent.component.html',
  styleUrls: ['./change-parent.component.css'],
  // changeDetection:ChangeDetectionStrategy.OnPush
})
export class ChangeParentComponent implements OnInit {
  inputVal:string | undefined
  counter=7;
 
  assig: any;
  color:string='green';
  childvarble:string=''
  constructor() { 

  }
  // increment(){
  //   this.counter=this.counter+1
  //   console.log(this.counter);
    
  // }
  ngOnInit(): void {
    console.log(" parent ng on int triggered");
    
  //  setInterval(()=>{
  //    this.arr=['banana']
  //  },2000)
  const promise=new Promise(resolve=>{
    resolve('promise working')
  })
  promise.then(res=>console.log(res)
  )
  const oberverbe=new Observable(sub=>{
    sub.next('method 1');
    sub.next('method 2')
    sub.next('method 3');
    sub.next('method 4')

  })
  oberverbe.subscribe(data=>{
    console.log(data);
    
  })
    
  }
  chldFun(e: string){
this.childvarble=e
  }
 
}
