import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeParentComponent } from './change-parent.component';

describe('ChangeParentComponent', () => {
  let component: ChangeParentComponent;
  let fixture: ComponentFixture<ChangeParentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeParentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChangeParentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
