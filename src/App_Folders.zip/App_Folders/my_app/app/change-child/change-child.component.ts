import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-change-child',
  templateUrl: './change-child.component.html',
  styleUrls: ['./change-child.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ChangeChildComponent implements OnInit {
 
  constructor() { }
@Input() counter=2
@Input() childCatch: any;
@Output()newItem=new EventEmitter<string>();
  ngOnInit(): void {
    console.log("chid ngonit triggered");
    this.newItem.emit('hi this is from child component')
  }
 
}
