import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsComponent } from './forms/forms.component';
import { ProductsComponent } from './products/products.component';
import { ViewsComponent } from './views/views.component';
import {FormsModule}  from '@angular/forms';
import { CheckoutComponent } from './login/login.component';
import {ReactiveFormsModule} from '@angular/forms';
import { RegistrationComponent } from './registration/registration.component';
import { ChildComponent } from './child/child.component';
import { ParentComponent } from './parent/parent.component';
import { ChangeParentComponent } from './change-parent/change-parent.component';
import { ChangeChildComponent } from './change-child/change-child.component';
import { ParamRoutingComponent } from './param-routing/param-routing.component';
import { InterpolationComponent } from './interpolation/interpolation.component';
import { DirectivesComponent } from './directives/directives.component'
import { Restrict } from './child/child.directive';
import { UsersService } from './Users/users.service';
import { LifecyclesComponent } from './lifecycles/lifecycles.component';
import {HttpClientModule} from '@angular/common/http';
import { RxjsObservablesComponent } from './rxjs-observables/rxjs-observables.component';
import { StoreMgmentComponent } from './store-mgment/store-mgment.component'
import { AlphabetsComponent } from './login/login.directive';
import { NavbarComponent } from './navbar/navbar.component';
import { Store, StoreModule } from '@ngrx/store';
import { FormReducer } from './store/reducer/reducer';
import { SelectProductComponent } from './select-product/select-product.component';
// >>>>>>>>>>>>>>>>>>>>>
import { Component, Inject, enableProdMode, ViewChild, OnDestroy } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { WjGridModule } from '@grapecity/wijmo.angular2.grid';
import { WjChartModule } from '@grapecity/wijmo.angular2.chart';
import { CommonModule } from '@angular/common';
import { OrdersComponent } from './orders/orders.component';

// import * as wjcCore from '@grapecity/wijmo';
// import * as wjcGrid from '@grapecity/wijmo.grid';
// import { CellMaker, SparklineMarkers } from '@grapecity/wijmo.grid.cellmaker';
// import { WjGridModule } from '@grapecity/wijmo.angular2.grid';
// import { WjGridGrouppanelModule } from '@grapecity/wijmo.angular2.grid.grouppanel';
// import { WjGridFilterModule } from '@grapecity/wijmo.angular2.grid.filter';
// import { WjGridSearchModule } from '@grapecity/wijmo.angular2.grid.search';
// import { WjInputModule } from '@grapecity/wijmo.angular2.input';

//>>>>>>>>>>>>>>>>>
@NgModule({
  declarations: [
    AppComponent,
    FormsComponent,
    ProductsComponent,
    ViewsComponent,
    CheckoutComponent,
    RegistrationComponent,
    ChildComponent,
    ParentComponent,
    ChangeParentComponent,
    ChangeChildComponent,
    ParamRoutingComponent,
   OrdersComponent,
    InterpolationComponent,
    DirectivesComponent,
    Restrict,
    LifecyclesComponent,
    RxjsObservablesComponent,
    StoreMgmentComponent,
    AlphabetsComponent,
    NavbarComponent,
    SelectProductComponent,
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule,
    WjChartModule,
    WjGridModule,
  
    StoreModule.forRoot({data:FormReducer}) , 
    
  ],
  providers: [UsersService,],
  bootstrap: [AppComponent]
})
export class AppModule { }
