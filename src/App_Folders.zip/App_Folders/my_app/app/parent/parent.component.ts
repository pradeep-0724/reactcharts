import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnInit } from '@angular/core';
import { __values } from 'tslib';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit,OnChanges,DoCheck,AfterContentChecked,AfterContentInit,AfterViewChecked,AfterViewInit  {
parentVar="this is from parent var"
frmChild: any;
  constructor() { 
    console.log("parent component constructor");
    
  }
  ngAfterViewChecked(): void {
    console.log("after view checed");
    
  }
  ngAfterViewInit(): void {
    console.log("after view init");
    
  }
  ngAfterContentInit(): void {
    console.log("after content init");
   
  }
  ngAfterContentChecked(): void {
    console.log("after content checked");
    
  }
  ngDoCheck() {
    console.log("do check is worked in parent");
    
  }

  ngOnInit(): void {
    console.log("parent component ngonit");
    
  }
  ngOnChanges() {
    console.log("ngonchanges from parent component frpm child");
  }
  click(value: any){
this.frmChild=value
  }
 
 
}
