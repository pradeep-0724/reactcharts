import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  options: object[] = [
    {
    "state": "Andhrapradesh", 'districts': [{ 'distrit': 'vizianagaram', 'mandals': ['merakamudidam', 'chiperupalli', 'dattirajeru'] },
    { 'distrit': 'visakhapatnam', 'mandals': ['gajuwaka', 'nad juncion', 'tadepalli'] }, { 'distrit': 'srikakulam', 'mandals': ['palasa', 'palakonda', 'rajam'] }]
  },
    {
      "state": "Telanagana", 'districts': [{ 'distrit': 'hyderabad', 'mandals': ['amirpet', 'banjarahills', 'jubileehills',"it park"] },
      { 'distrit': 'sangareddy', 'mandals': ['kangti', 'Sirgapoor', 'Kalher','	Narayankhed'] }, { 'distrit': 'siddipet', 'mandals': ['s-urban', 's-rural', 'Chinnakodur'] }, { 'distrit': 'warangal', 'mandals': ['Geesugonda', 'Wardhannapet.', 'Rayaparthy','Sangem'] }]
    },
    {
      "state": "Tamilnadu", 'districts': [{ 'distrit': 'ariyalur', 'mandals': ['Elakkurichi', 'Keezhapalur', ' Nagamangalam'," Thirumanur"] },
      { 'distrit': 'chennai', 'mandals': ['THIRUVOTRIYUR', 'MANALI', '	MADHAVARAM','		Udayarpalayam'] }, { 'distrit': 'coimbatore', 'mandals': ['	Pollachi', 'Sulur', '	Mettupalayam','	Valparai'] }, { 'distrit': 'chengalapttu', 'mandals': ['chengalapttu', 'Madurantakam', 'Maraimalai Nagar','Nandivaram-Guduvancheri'] }]
    },
    {
      "state": "Karnataka", 'districts': [{ 'distrit': 'bagalkot', 'mandals': ['Badami', 'Kerur Kulageri', 'Anagwadi'," Bilgi"] },
      { 'distrit': 'ballari', 'mandals': ['HADAGALLI', 'HOSPET', '	SANDUR','		SIRUGUPPA'] }, { 'distrit': 'belagavi', 'mandals': ['	BELGAUM', 'HUKER', 'PARASGAD','	RAMDURG'] }, { 'distrit': 'bengaluru', 'mandals': ['bengaluru-north', 'bengaluru-south', 'bengaluru-east','bengaluru-west'] }]
    },
  ]
  checkboArray=['C','Java','HTML','React','Angular','Javascript','Typescript','NodeJs']

  constructor() { }
  getstates() {
    return this.options
  }
  getcheckboxes(){
    return this.checkboArray
  }
}
