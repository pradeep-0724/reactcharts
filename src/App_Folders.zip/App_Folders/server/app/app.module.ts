import {  NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './users/users.component';
import { OrdersComponent } from './orders/orders.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserService } from './user.service';
import { CssPracticeComponent } from './css-practice/css-practice.component';
import { WijmoTableComponent } from './wijmo-table/wijmo-table.component';
import { WjGridModule } from '@grapecity/wijmo.angular2.grid';
import { DataService } from './wijmo-table/app.data';
import { WjGridFilterModule } from '@grapecity/wijmo.angular2.grid.filter';
import '@grapecity/wijmo.styles/wijmo.css';
import { PianoDemoComponent } from './piano-demo/piano-demo.component';
import {  SafeCurrencyPipe } from './wijmo-table/app.pipe';
import { WjInputModule } from '@grapecity/wijmo.angular2.input';
import { WjGridGrouppanelModule } from '@grapecity/wijmo.angular2.grid.grouppanel';
import { WijmoStudentsComponent } from './wijmo-students/wijmo-students.component';
import { wijmoReducer } from './wijmo-students/reducer/reducer';
import { StoreModule } from '@ngrx/store';
import { OtpDemoComponent } from './otp-demo/otp-demo.component';
import { DatePipe } from '@angular/common';
import { PaginationComponent } from './pagination/pagination.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { PreferedDdownComponent } from './prefered-ddown/prefered-ddown.component';
import {CheckoutComponent} from './login/login.component'
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import {RegistrationComponent} from './registration/registration.component';
import { ZuperHomeComponent } from './zuper-home/zuper-home.component';
import { ZuperJobsComponent } from './zuper-jobs/zuper-jobs.component'

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    OrdersComponent,
    CssPracticeComponent,
    WijmoTableComponent,
    PianoDemoComponent,
    CheckoutComponent,
    WijmoStudentsComponent,
    OtpDemoComponent,
    PaginationComponent,
    PreferedDdownComponent,
    RegistrationComponent,
    ZuperHomeComponent,
    ZuperJobsComponent,

    
  ],
  imports: [
    BrowserModule,
    WjGridModule,
    WjGridFilterModule,
    WjInputModule,
    HttpClientModule,
    NgxPaginationModule,
    WjGridGrouppanelModule, 
   
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    ModalModule,
    StoreModule.forRoot({wijmodata:wijmoReducer})
  ],
  providers: [UserService,DataService,SafeCurrencyPipe,DatePipe,BsModalService],
  bootstrap: [AppComponent]
})
export class AppModule { }

