import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
// import { loginFun, registerFun } from '../store/action/actions';
import { UsersService } from '../UsersSrv/users.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerform: FormGroup;
  registerdata: any;
  flag: any;
  agent: any;
  storedata: any;
  formdata: any[] = [];
  statusmsg: string = '';
  useremails: string[] = [];
  constructor(private store: Store<{ data: { data: object } }>,
    private formbuilder: FormBuilder, private rtr: Router, private userServ: UsersService, private activroute: ActivatedRoute, private http: HttpClient) {

    this.registerform = formbuilder.group({
      firstname: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^([a-zA-Z ]{3,15})$/)]],
      lastname: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(7), Validators.pattern(/^(?=.*[0-9])(?=.*[!@#$%^&*])(?=.*[A-Z])(?=.*[a-z])[a-zA-Z0-9!@#$%^&*]{6,16}$/)]],
      cpassword: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern('[6-9]{1}[0-9]{9}')]],
      gender: [''],
      send_newsletter: [''],
      agree: ['']
      //   email:['',[Validators.required, Validators.email]],
      //  password:['',[Validators.required,Validators.minLength(3)]],
    })
  }
  getData() {
    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {
      this.formdata = res
      console.log(this.formdata);

    })
  }
  ngOnInit() {
    // console.log(this.rtr.url);
    // console.log(window.location.href);
    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {
      this.formdata = res
      console.log(this.formdata);

    })


  }
  submitData() {
    console.log("jhgfd");


    for (let ele of this.formdata) {
     
      this.useremails.push(ele.email);
    }
    if (this.useremails.includes(this.registerform.value.email)) {
      this.statusmsg = 'Already email exists';

    } else {
      this.http.post<any>('http://localhost:3000/formdata', this.registerform.value).subscribe(res => {
        console.log(res);

      })
    }
    console.log(this.useremails);

  }
  goback() {
    this.rtr.navigate(['login'])

  }
}
