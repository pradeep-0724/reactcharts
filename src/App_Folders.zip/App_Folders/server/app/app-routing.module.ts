import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CheckoutComponent } from './login/login.component';
import { OrdersComponent } from './orders/orders.component';
import { OtpDemoComponent } from './otp-demo/otp-demo.component';
import { PaginationComponent } from './pagination/pagination.component';
import { PianoDemoComponent } from './piano-demo/piano-demo.component';
import { PreferedDdownComponent } from './prefered-ddown/prefered-ddown.component';
import { RegistrationComponent } from './registration/registration.component';
import { UsersComponent } from './users/users.component';
import { WijmoStudentsComponent } from './wijmo-students/wijmo-students.component';
import { ZuperHomeComponent } from './zuper-home/zuper-home.component';
import { ZuperJobsComponent } from './zuper-jobs/zuper-jobs.component';

const routes: Routes = [
  {path:'users',component:UsersComponent},
  {path:'orders',component:OrdersComponent},
  {path:'piano',component:PianoDemoComponent},
  {path:'wijmodata',component:WijmoStudentsComponent},
 {path:'otpdemo',component:OtpDemoComponent},
 {path:'paginate',component:PaginationComponent},
 {path:'preference',component:PreferedDdownComponent},
 {path:'login',component:CheckoutComponent},
 {path:'register',component:RegistrationComponent},
 {path:'',component:ZuperHomeComponent},
 {path:'zuperjobs/:id',component:ZuperJobsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
