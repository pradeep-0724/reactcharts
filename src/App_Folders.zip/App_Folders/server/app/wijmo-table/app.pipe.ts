import * as wjcCore from '@grapecity/wijmo';
import {  Pipe } from '@angular/core';


// SafeCurrency pipe
@Pipe({
    name: 'safeCurrency'
})
export class SafeCurrencyPipe {
    transform(value: any, args: string[]): any {
        if (wjcCore.isNumber(value)) {
            return wjcCore.Globalize.formatNumber(value, 'c');
        }
        if (!wjcCore.isUndefined(value) && value !== null) {
            return wjcCore.changeType(value, wjcCore.DataType.String);
        }
        return '';
    }
}

// @NgModule({
//     //imports: [Pipe],
//     declarations: [SafeCurrencyPipe],
//     exports: [SafeCurrencyPipe],
// })

// export class AppPipesModule {
// }

