import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WijmoTableComponent } from './wijmo-table.component';

describe('WijmoTableComponent', () => {
  let component: WijmoTableComponent;
  let fixture: ComponentFixture<WijmoTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WijmoTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WijmoTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
