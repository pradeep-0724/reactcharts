


// 
import { CellMaker, SparklineMarkers } from '@grapecity/wijmo.grid.cellmaker';

//
import { Component, Inject, enableProdMode, NgModule, ViewChild, HostListener, OnInit } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import  * as wjcCore from '@grapecity/wijmo'
import * as wjcGrid from '@grapecity/wijmo.grid';

import { Country, DataService, KeyValue } from './app.data'
import '@grapecity/wijmo.touch';



//
@Component({
  selector: 'app-wijmo-table',
  templateUrl: './wijmo-table.component.html',
  styleUrls: ['./wijmo-table.component.css']
})
export class WijmoTableComponent implements OnInit {
    private itemsCountt: number = 500;
    private lastIdd: number = this.itemsCountt;
    private dataSvcc: DataService;
    
    private itemsSourcee: wjcCore.CollectionView;
    private productMapp: wjcGrid.DataMap<number, KeyValue>;
    private countryMapp: wjcGrid.DataMap<number, Country>;
    private colorMapp: wjcGrid.DataMap<number, KeyValue>;
    private historyCellTemplatee: wjcGrid.ICellTemplateFunction;
    private ratingCellTemplatee: wjcGrid.ICellTemplateFunction;
   

    // references FlexGrid named 'flex' in the view
    @ViewChild('flex', { static: true }) flex!: wjcGrid.FlexGrid;

    get productMap(): wjcGrid.DataMap<number, KeyValue> {
        return this.productMapp;
    }

    get countryMap(): wjcGrid.DataMap<number, Country> {
        return this.countryMapp;
    }

    get colorMap(): wjcGrid.DataMap<number, KeyValue> {
        return this.colorMapp;
    }

    get itemsSource(): wjcCore.CollectionView {
        return this.itemsSourcee;
    }

    get itemsCount(): number {
        return this.itemsCountt;
    }

    set itemsCount(value: number) {
        if (this.itemsCountt != value) {
            this.itemsCountt = value;
            this._handleItemsCountChange();
        }
    }

    get historyCellTemplate(): wjcGrid.ICellTemplateFunction {
        return this.historyCellTemplatee;
    }

    get ratingCellTemplate(): wjcGrid.ICellTemplateFunction {
        return this.ratingCellTemplatee;
    }

   

    constructor(@Inject(DataService) dataSvc: DataService) {
        this.dataSvcc = dataSvc;
      

        // initializes items source
        this.itemsSourcee = this._createItemsSource();

        // initializes data maps
        this.productMapp = this._buildDataMap(this.dataSvcc.getProducts());
        this.countryMapp = new wjcGrid.DataMap<number, Country>(this.dataSvcc.getCountries(), 'id', 'name');
        this.colorMapp = this._buildDataMap(this.dataSvcc.getColors());

        // initializes cell templates
        this.historyCellTemplatee = CellMaker.makeSparkline({
            markers: SparklineMarkers.High | SparklineMarkers.Low,
            maxPoints: 25,
            label: 'price history',
        });

        this.ratingCellTemplatee = CellMaker.makeRating({
            range: [1, 5],
            label: 'rating'
        });

        // initializes export
       
    }
    ngOnInit(): void {
      
        console.log(new Date(2022,1,29),"date");
        
    
    }
    getCountry(item: any) {
        const country = this.countryMapp.getDataItem(item.countryId);
        return country ? country : Country.NotFound;
    }

    getColor(item: any) {
        const color = this.colorMapp.getDataItem(item.colorId);
        return color ? color : KeyValue.NotFound;
    }

    getChangeCls(value: any) {
        if (wjcCore.isNumber(value)) {
            if (value > 0) {
                return 'change-up';
            }
            if (value < 0) {
                return 'change-down';
            }
        }
        return '';
    }

   

    private _createItemsSource(): wjcCore.CollectionView {
        const data = this.dataSvcc.getData(this.itemsCountt);
        const view = new wjcCore.CollectionView(data, {
            getError: (item: any, prop: any) => {
                const displayName:any = this.flex.columns.getColumn(prop).header;
                return this.dataSvcc.validate(item, prop, displayName);
            }
        });
        // @ts-ignore
        view.collectionChanged.addHandler((s: wjcCore.CollectionView, e: wjcCore.NotifyCollectionChangedEventArgs) => {
            // initializes new added item with a history data
            if (e.action === wjcCore.NotifyCollectionChangedAction.Add) {
                e.item.history = this.dataSvcc.getHistoryData();
                e.item.id = this.lastIdd;
                this.lastIdd++;
            }
        });
        return view;
    }

    private _disposeItemsSource(itemsSource: wjcCore.CollectionView): void {
        if (itemsSource) {
            itemsSource.collectionChanged.removeAllHandlers();
        }
    }

    // build a data map from a string array using the indices as keys
    private _buildDataMap(items: string[]): wjcGrid.DataMap<number, KeyValue> {
        const map: KeyValue[] = [];
        for (let i = 0; i < items.length; i++) {
            map.push({ key: i, value: items[i] });
        }
        return new wjcGrid.DataMap<number, KeyValue>(map, 'key', 'value');
    }

    private _handleItemsCountChange() {
        this._disposeItemsSource(this.itemsSourcee);

        this.lastIdd = this.itemsCountt;
        this.itemsSourcee = this._createItemsSource();
    }
}
  enableProdMode();
  // Bootstrap application with hash style navigation and global services.
  platformBrowserDynamic().bootstrapModule(WijmoTableComponent);











   //   }
  //   @HostListener('window : load',['$event']) 
  //   onload(event:Event){
  //     this.view.sortDescriptions.clear();
  //     console.log("loadinfggg");
      
  //     // add the new sorts
  //     (<HTMLInputElement>event.target).value.split(',').forEach(prop => {
  //         // Sort country in ascending order, other in descending order
  //         this.view.sortDescriptions.push(new wijmo.SortDescription(prop, prop === 'Country'));
  //     });
      
  //   }