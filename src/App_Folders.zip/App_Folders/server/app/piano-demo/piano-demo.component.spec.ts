import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PianoDemoComponent } from './piano-demo.component';

describe('PianoDemoComponent', () => {
  let component: PianoDemoComponent;
  let fixture: ComponentFixture<PianoDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PianoDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PianoDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
