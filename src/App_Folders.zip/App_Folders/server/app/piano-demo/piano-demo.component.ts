import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-piano-demo',
  templateUrl: './piano-demo.component.html',
  styleUrls: ['./piano-demo.component.css']
})
export class PianoDemoComponent implements OnInit {
  audio: HTMLElement | null | undefined;
  src:HTMLImageElement | null | undefined
    constructor(private rtr: Router,private store:Store<{wijmodata:{wijmodata:object}}>) { }
  
    ngOnInit(): void {
      this.store.select('wijmodata').subscribe((e:any)=>{
        console.log(e.arr);
        
    })
    }
   
   
    @HostListener('keypress',['$event']) keypress(event:any){
      console.log(event.keyCode);
      
    }
    @HostListener('document:keypress', ['$event'])
    onDocumentClick(event: KeyboardEvent) {
     console.log(event.keyCode);
     console.log(event.key);
  
    //  console.log(typeof(event.keyCode));
    //   this.audio=document.getElementById('audo')
    //  console.log(this.audio);
    const divtags=document.querySelectorAll('.key')
    console.log(divtags);
    divtags.forEach((ele)=>{
    if(String(event.keyCode)==ele.getAttribute('data-key')){
    var myAud = document.getElementById(ele.id) as HTMLImageElement;
    console.log(myAud.src);
  
    var sound1 = new Audio(myAud.src);
    sound1.play();
    
    ele.classList.add('selectaudio')
   }else{
    ele.classList.remove('selectaudio')
   }
  
  })
    }

}



//     console.log(ele);
//     console.log(document.getElementById(ele.id));
//     console.log(ele.getAttribute('src'));
//     console.log((<HTMLImageElement>document.getElementById(ele.id)).src);
//     console.log(myAud.src.split('4200'));
