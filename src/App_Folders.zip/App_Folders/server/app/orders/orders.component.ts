import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  audio: HTMLElement | null | undefined;
src:HTMLImageElement | null | undefined;
currentkey:number | undefined;
  constructor(private rtr: Router) { }

  ngOnInit(): void {
  }
 
 
  @HostListener('window:load',['$event']) load(event:any){
    console.log(event,"loading");
    
  }
  @HostListener('document:keypress', ['$event'])
  onDocumentClick(event: KeyboardEvent) {
    console.log(event);
    
   console.log(event.keyCode);
   console.log(event.key);

  
  const divtags=document.querySelectorAll('.key')
  console.log(divtags);
this.currentkey=event.keyCode
divtags.forEach((ele)=>{
  if(String(event.keyCode)==ele.getAttribute('data-key')){
    
  var myAud = document.getElementById(ele.id) as HTMLImageElement;
  console.log(myAud.src);

  var sound1 = new Audio(myAud.src);
  sound1.play();
  console.log(ele);
  console.log(document.getElementById(ele.id));
console.log(ele.getAttribute('src'));
console.log((<HTMLImageElement>document.getElementById(ele.id)).src);
console.log(myAud.src.split('4200'));
ele.classList.add('selectaudio')
 }else{
  ele.classList.remove('selectaudio')
 }

})
  }
}



// window.addEventListener('keydown', function (e) {
//  console.log("keydown");
 
// }, false);
