import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-css-practice',
  templateUrl: './css-practice.component.html',
  styleUrls: ['./css-practice.component.css']
})
export class CssPracticeComponent implements OnInit {
  @Input()prntchld:string='';
 
  constructor() { }

  ngOnInit(): void {
  }

}
