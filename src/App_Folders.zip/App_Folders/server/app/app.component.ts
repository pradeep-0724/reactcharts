import { Component, DoCheck } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent   {
  title = 'server';
  input:string='';
  submitinput: string=''
  selectform:FormGroup 
  counter=0
  options:string[]=["AndhraPradesh","tamilnadu","banglaore","goa","karnaataka","jharkand","uutarakand"]
  constructor( private router:Router,private formbuilder:FormBuilder){
    this.selectform=formbuilder.group({
    state:[''],
    singleSelect:['']
    })
  }
  Onsubmmit(){
    this.submitinput=this.input
  }
  submitdata(){
    console.log(this.selectform.value);
  }
  changecolor(event:any) {
    var target = event.target || event.srcElement;
    var buttonList = document.querySelectorAll("button");
    buttonList.forEach(function(button) {
  
      
      if (button === target && !button.classList.contains("active")) {
        return button.classList.add("active");
      }
      return button.classList.remove("active");
    });
    

    
}
 
  
}
