import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-zuper-jobs',
  templateUrl: './zuper-jobs.component.html',
  styleUrls: ['./zuper-jobs.component.css']
})
export class ZuperJobsComponent implements OnInit {

  constructor(private rtr:ActivatedRoute,private http:HttpClient) { }
status:string='';
selectedJobs:any[]=[]
data = [
  {
    job_id: 1,
    status: 'CONFIRMED',
    assigned_to: ['raghav', 'vijay'],
  },
  {
    job_id: 2,
    status: 'ON_MY_WAY',
    assigned_to: ['vijay'],
  },
  {
    job_id: 3,
    status: 'CONFIRMED',
    assigned_to: ['ranjith'],
  },
  {
    job_id: 4,
    status: 'STARTED',
    assigned_to: ['raghav'],
  },
  {
    job_id: 5,
    status: 'STARTED',
    assigned_to: ['ranjith'],
  },
  {
    job_id: 6,
    status: 'COMPLETED',
    assigned_to: ['vijay'],
  },
];
  ngOnInit(): void {
    this.rtr.params.subscribe((data)=>{
      console.log(data['id']);
      this.status=data['id']
    })
    this.data.map((ele)=>{
      if(ele.status===this.status){
        this.selectedJobs.push(ele)
      }
    })
    console.log(this.selectedJobs);
    
    
   
  }

}
