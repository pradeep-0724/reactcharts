import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZuperJobsComponent } from './zuper-jobs.component';

describe('ZuperJobsComponent', () => {
  let component: ZuperJobsComponent;
  let fixture: ComponentFixture<ZuperJobsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZuperJobsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ZuperJobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
