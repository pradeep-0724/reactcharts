import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferedDdownComponent } from './prefered-ddown.component';

describe('PreferedDdownComponent', () => {
  let component: PreferedDdownComponent;
  let fixture: ComponentFixture<PreferedDdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreferedDdownComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreferedDdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
