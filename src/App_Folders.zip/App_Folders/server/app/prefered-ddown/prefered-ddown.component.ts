import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prefered-ddown',
  templateUrl: './prefered-ddown.component.html',
  styleUrls: ['./prefered-ddown.component.css']
})
export class PreferedDdownComponent implements OnInit {
  firstdd: string = '';
  secdd: string = '';
  thrddd: string = '';
  fthdd: string = '';
  frthdd: string = '';
  startCounter: number = 0;
  onmywayCounter: number = 0;
  confimCounter: number = 0;
  completeCounter=0
  // sreevidya@zuper.co
  // resultArr.push({sttaus: ele.status, count: 1}]
  res={
    "confirmed":0,
    "onmyway":0,
    "started":0,
    "completed":0
  }
  data = [
    {
      job_id: 1,
      status: 'CONFIRMED',
      assigned_to: ['raghav', 'vijay'],
    },
    {
      job_id: 2,
      status: 'ON_MY_WAY',
      assigned_to: ['vijay'],
    },
    {
      job_id: 3,
      status: 'CONFIRMED',
      assigned_to: ['ranjith'],
    },
    {
      job_id: 4,
      status: 'STARTED',
      assigned_to: ['raghav'],
    },
    {
      job_id: 5,
      status: 'STARTED',
      assigned_to: ['ranjith'],
    },
    {
      job_id: 6,
      status: 'COMPLETED',
      assigned_to: ['vijay'],
    },
  ];

  locations1: string[] = ['Hyderabad', 'Chennai', 'Bangalore', 'Mumbai', 'Coiambatore'];
  locations2: string[] = [];
  locations3: string[] = [];
  locations4: string[] = [];
  locations5: string[] = [];
  constructor() { }

  ngOnInit(): void {
    console.log(this.data);
    console.log('jij')
    this.data.map((ele) => {
      console.log(ele.status)
      if (ele.status === 'CONFIRMED') {
        this.confimCounter += 1
      }
      else if (ele.status === 'ON_MY_WAY') {
        this.onmywayCounter+=1
      }
      else if(ele.status==='COMPLETED'){
        this.completeCounter+=1
      }
      else{
        this.startCounter+=1
      }
    })
   console.log(this.startCounter,this.confimCounter,this.onmywayCounter);
   
    this.res.started=this.startCounter;
    this.res.onmyway=this.onmywayCounter;
    this.res.confirmed=this.confimCounter;
    this.res.completed=this.completeCounter
    console.log(this.res);

  }
  Fstdd(e: any) {
    this.locations2 = [];
    this.secdd = '';
    this.thrddd = '';
    this.frthdd = '';
    this.fthdd = '';
    console.log('changed');
    console.log(this.locations1);

    this.locations1.map((ele, i) => {
      console.log(ele, i);
      if (ele != e.target.value) {

        this.locations2.push(ele)

      }

    })
    console.log(this.locations2);

  }
  Secdd(e: any) {
    this.locations3 = [];
    this.thrddd = '';
    this.frthdd = '';
    this.fthdd = '';
    this.locations2.map((ele, i) => {

      if (ele != e.target.value) {
        this.locations3.push(ele)
      }

    })
  }
  Thrddd(e: any) {
    this.locations4 = [];
    this.frthdd = '';
    this.fthdd = '';
    this.locations3.map((ele, i) => {

      if (ele != e.target.value) {
        this.locations4.push(ele)
      }

    })
  }
  Frthdd(e: any) {
    this.locations5 = []
    this.locations4.map((ele, i) => {

      if (ele != e.target.value) {
        this.locations5.push(ele)
      }

    })
  }
}
