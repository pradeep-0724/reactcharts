
import { createAction, props } from "@ngrx/store";


export const newDataFun=createAction('newDataFun',props<{value:any}>());


