export const initiState:Data = {
    roll: '',
    names: '',
    date: '',
    gender: '',
    id: '',
    subject1: '',
    subject2: '',
    subject3: '',
    total: '',
    arr:[]
}
export interface Data{
    roll:string,
    names:string,
    date:string,
    gender:string,
    id:string,
    subject1:string,
    subject2:string,
    subject3:string,
    total:string,
    arr:object[]
}
