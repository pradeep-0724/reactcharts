import '@grapecity/wijmo.styles/wijmo.css';

import { Component, OnDestroy, OnInit, ViewChild,TemplateRef } from '@angular/core';
import * as wjcGrid from '@grapecity/wijmo.grid';
import * as wijmo from '@grapecity/wijmo';
import { Store } from '@ngrx/store';
import * as wjGrid from '@grapecity/wijmo.grid';
import * as wjcCore from '@grapecity/wijmo';
import * as wjCore from '@grapecity/wijmo';
import { CollectionView } from '@grapecity/wijmo';

import { isNumber, changeType, DataType } from '@grapecity/wijmo';
import '@grapecity/wijmo.input';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { newDataFun } from './action/action';
import { SortDescription } from '@grapecity/wijmo'
import { DatePipe } from '@angular/common';
@Component({
    selector: 'app-wijmo-students',
    templateUrl: './wijmo-students.component.html',
    styleUrls: ['./wijmo-students.component.less']
})
export class WijmoStudentsComponent implements OnInit, OnDestroy {


    // view: any[];
   
    

    @ViewChild('flex', { static: true }) flex!: wjcGrid.FlexGrid;
    datePipeString: any;
    rdate:any;
    modalRef!: BsModalRef;  
    view = new CollectionView(this.getData(), {
        getError: (item: any, prop: string, parsing: boolean) => {
           
            
            
            // data errors
            if ((prop == 'subject1' && item.subject1 < 0||item.subject1>100) ||(prop == 'subject2' && item.subject2 < 0||item.subject2>100)||(prop == 'subject3' && item.subject3 < 0||item.subject3>100)) {
                return 'marks  cannot be negative! and above 100';
            }
            if (prop == 'total' && item.total >300 ||item.total <0) {
                return 'total cannot be negative! and above 300';
            }
            if ((prop == 'roll' && item.roll ==null) ||(prop == 'name' && item.name =='')||(prop == 'subject1' && item.subject1 =='')||(prop == 'subject2' && item.subject2 =='')||(prop == 'subject3' && item.subject3 =='')||(prop == 'total' && item.total =='')) {
                return 'all fields required';
            }
            // if (( item.roll =='') ||(item.name =='')||( item.subject1 =='')||( item.subject2 =='')||( item.subject3 =='')||(item.total =='')) {
            //     return false ;
            // }
            // no errors
            return null;
        }
    });
   
    constructor(private store: Store<{ wijmodata: { wijmodata: object } }>,private datepipe:DatePipe,private modalService: BsModalService) {
        this.datePipeString = datepipe.transform(Date.now(),'yyyy/MM/dd');
        console.log(this.datePipeString );
       
        // this.view = this.getData()
        this.rdate=new Date(Math.floor(Math.random()*1000))
        // console.log("new dataa", this.view);
        // console.log(this.rdate);
       
    }
    openModalWithClass(template: TemplateRef<any>) {  
        this.modalRef = this.modalService.show(  
          template,  
          Object.assign({}, { class: 'gray modal-lg' })  
        ); 
        
 
      
    }  
  
   
    ngOnDestroy(): void {
        console.log(this.view._src, "from destroy");
        this.store.dispatch(newDataFun({ value: this.view }))
        console.log('row aded in destroy');

    }
    dataMap = this.getDataMap();

    private getDataMap(): wjcGrid.DataMap {
        let gender = 'Male,Female'.split(','),
            arr = gender.map((name, id) => { return { id: id, name: name } });
        return new wjcGrid.DataMap(arr, 'id', 'name');
    }
    ngOnInit(): void {

        this.store.select('wijmodata').subscribe((e: any) => {
            console.log(e.arr._src);
          
            if (e.arr._src.length > 0) {
                this.view = e.arr
                console.log(this.view);
            }
        })
      
      
    }

    allcolums(event:any){ 
        console.log(this.view._src);
        this.view = new wjcCore.CollectionView( this.getData(), {
            collectionChanged: (s:any,e:any) => {
                if(this.flex && e.action == 2 && e.index != -1){
                    for(let i=0; i<this.flex.columns.length; i++) {
                        let col:any = this.flex.columns[i];
                        if(e.item[col.binding] == undefined || e.item[col.binding].toString().trim() == ''){
                            s.items.splice(e.index,1);
                            s.refresh();
                         
                            alert('Invalid row data')
                            break;
                        }
                    }
                }
            }
        })
        console.log("new adeded this.allcolums" );    
    }
    initializeGrid(flex: wjcGrid.FlexGrid) {
       
        console.log(this.view._src);
     
        console.log("new adeded this.initialsed" );
        
        let sd = new wjcCore.SortDescription('total', false);
        flex.collectionView.sortDescriptions.push(sd);
       
        flex.cellEditEnding.addHandler((s: wjcGrid.FlexGrid, e: wjcGrid.CellEditEndingEventArgs) => {
           
            let col = s.columns[e.col];
            
            
            let value = changeType(s.activeEditor.value, DataType.Number);
            // console.log( col.binding?.length,'col');
        
           
           
            
            if (col.binding == 'subject1' || col.binding == 'subject2'||col.binding == 'subject3'||
            col.binding == 'roll' || col.binding == 'names'||col.binding == 'gender'||col.binding=='total') {
                let value = changeType(s.activeEditor.value, DataType.Number);
                if ( value ==null ||value=='') {
                    e.cancel = true;
                    e.stayInEditMode = true;
                    // alert('Please enter all fields')
                }
            }
            if (col.binding == 'subject1' || col.binding == 'subject2' || col.binding == 'subject3') {
                let value = changeType(s.activeEditor.value, DataType.Number);
                if (!isNumber(value) || value < 0 || value > 100) {
                    e.cancel = true;
                    e.stayInEditMode = true;
                
                    // this.view=this.getCalculatedView()
                    // alert('Please enter marks in between 1 to 100.')
                }

            }
            if (col.binding == 'total' ) {
                let value = changeType(s.activeEditor.value, DataType.Number);
                if (!isNumber(value) || value < 0 || value > 300) {
                    e.cancel = true;
                    e.stayInEditMode = true;
                    // this.view=this.getCalculatedView()
                    // alert('Please enter marks in between 1 to 100.')
                }

            }
           
            if (col.binding == 'names') {
                let value = changeType(s.activeEditor.value, DataType.Number);
                let namereg = '^([a-zA-Z]{2,})'
                if (!value.match(namereg)) {
                    e.cancel = true;
                    e.stayInEditMode = true;
                    alert('Please enter name.')
                }
            }
            // flex.itemFormatter=(panel,r,c,cell)=>{
            //     if(panel.cellType==wijmo.flex.CellType.ColumnHeader&&c==4){
            //       cell.innerHTML="Total";
            //   }
            //   if(panel.cellType==wijmo.flexgrid.CellType.Cell&&c==4){
            //       var curStudentData=panel.rows[r].dataItem;
            //     var total=curStudentData['maths']+curStudentData['english']+curStudentData['hindi'];
            //     cell.innerHTML=total;
                
            //   }
            // }
            // flex.itemFormatter = function (panel, r, c, cell) {  
            //     if (panel.cellType == wijmo.flex.CellType.Cell) {  
            //        var flex = panel.grid;  
            //        //if its calculated column  
            //        if (c == 3) {  
            //          flex.beginUpdate();  
            //          //get data from other columns for this row i.e. profilt=sales-expenses  
            //          var calculatedData = parseInt(flex.getCellData(r, 1, false)) - parseInt(flex.getCellData(r, 2, false));  
            //          //set the value in the calculated column  
            //          flex.setCellData(r, c, calculatedData, true);  
            //          flex.endUpdate();  
            //        }  
            //     }  
            // }
            
             

        });

    }
   
    
    
    private getData() {
        let names = 'Andrew,Elise,Dean,Kate,Smit,Dwars,Vyuhe,Mooley'.split(','),
         data = [];
        let map = this.getDataMap(),
            len = map.collectionView.items.length;
        for (let i = 0; i < names.length; i++) {
            
            const today = new Date();
            const yyyy = Math.floor(Math.random() * 10) + 1990;
            let mm:any = Math.floor(Math.random()*10)+3 // Months start at 0!
            let dd:any = Math.floor(Math.random()*10)*3;
            
            if (dd < 10){
               
                dd = '0' + dd;
            } 
            if (mm < 10) mm = '0' + mm;
            
            const formattedToday = dd + '/' + mm + '/' + yyyy;
            // const date = new Date(Math.floor(Math.random() * 10) + 1990, Math.floor(Math.random() * 10) % 12, Math.floor(Math.random() * 10) % 30);
            let subject1 = Math.floor(Math.random() * 100);
            let subject2 = Math.floor(Math.random() * 100);
            let subject3 = Math.floor(Math.random() * 100);
            data.push({
                id: i,
                names: names[i],
                roll: i + 1,
                date: formattedToday ,
                gender: Math.floor(Math.random() * len),
                subject1: subject1,
                subject2: subject2,
                subject3: subject3,
                total: subject1 + subject2 + subject3,
                
            });
        }
         
        return data;
    }
}
