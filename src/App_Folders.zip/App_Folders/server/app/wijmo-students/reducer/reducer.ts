
import { createReducer, on } from "@ngrx/store";
import { newDataFun } from "../action/action";
import { initiState } from "../state/state";


const _wijmoReducer=createReducer(initiState,
    on(newDataFun, (state,action) => {
        console.log(action.value);
        
        return {
            ...state,
            arr:action.value
            
        }
    }),
    

)

export function wijmoReducer(state: any, action: any) {
    return _wijmoReducer(state, action);
}