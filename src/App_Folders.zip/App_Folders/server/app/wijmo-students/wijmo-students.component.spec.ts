import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WijmoStudentsComponent } from './wijmo-students.component';

describe('WijmoStudentsComponent', () => {
  let component: WijmoStudentsComponent;
  let fixture: ComponentFixture<WijmoStudentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WijmoStudentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WijmoStudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
