import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CollectionView }  from '@grapecity/wijmo';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css']
})
export class PaginationComponent implements OnInit {
allUsers:any;
// totalRecords: Number|undefined;
page=1
nthpage:number=1;
recpage:number=3;
  constructor( private http:HttpClient) { }

  ngOnInit(): void {
   
    this.http.get('https://jsonplaceholder.typicode.com/users').subscribe((ele)=>{
      this.allUsers=ele
      console.log('jijij',ele);
      
      console.log(this.allUsers);
      console.log(this.nthpage);
      
      return new CollectionView(this.allUsers, {
        perpageSize: 5,
    });
    
    })
  }
  
   
  
  
}
