import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router, RouteReuseStrategy } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit, DoCheck {
  user: { id: string; name: string } | undefined;
  states: any;
  districts: string | undefined;
  selectopt: FormGroup
  servdistricts: any;
  mandals: any;
  data: any;
  name: string = '';
  // ..........checkbox..........
  checkboxar: string[] = []
  selectedcheckArr: string[] = []
  // ............checkbox end.........
  constructor(private activroute: ActivatedRoute, private route: Router, private userserv: UserService, private formbuilder: FormBuilder) {
    this.selectopt = formbuilder.group({
      opt: [''],
      district: [''],
      mandal: [''],
      checkboxs: ['']
    })


  }
  ngDoCheck(): void {
    // console.log( window.location.href);
    // console.log(this.route.url);
    // this.data=sessionStorage.getItem('data')
    //      this.data=JSON.parse(this.data)
    //      console.log(this.data);
    //  this.data.opt=this.selectopt.value.opt
    //  this.data.district=this.selectopt.value.district
    //  this.data.mandal=this.selectopt.value.mandal


    // this.data=JSON.parse(this.data)


  }
  ngOnInit(): void {
    //    this.user={
    //      id:this.activroute.snapshot.queryParams['id'],
    //      name:this.activroute.snapshot.params['name']
    //    }

    //    console.log(this.activroute.snapshot.params);
    //    console.log(this.activroute.snapshot.queryParams);
    // console.log(this.route.url,"url path");

    //    this.activroute.params.subscribe((data)=>{
    //      this.user={
    //        id:data['id'],
    //        name:data['name']
    //      }

    //      console.log(data);
    //    })

    this.states = this.userserv.getstates()
    this.checkboxar = this.userserv.getcheckboxes()

    console.log(this.states);
    // for (let ele of this.states) {
    //   console.log(ele.state);

    // }

  }
  selectstate() {
    console.log("state");
    console.log(this.selectopt.value.opt);
    for (let ele of this.states) {

      if (ele.state === this.selectopt.value.opt) {
        this.servdistricts = ele.districts
        console.log('servdistricts', this.servdistricts);
      }

    }
  }
  selectdistrict() {
    console.log(this.selectopt.value.district, "selected district ");
    for (let ele of this.servdistricts) {

      if (ele.distrit === this.selectopt.value.district) {
        console.log(ele.mandals, "ele");
        this.mandals = ele.mandals
        for (let ele of this.mandals) {
          console.log(ele);

        }
        console.log('servdistricts', this.selectopt.value.district, ele.distrit);
      }

    }
  }
  selectdata() {
    console.log(this.selectopt.value);
    this.route.navigate(['orders'])
    
    console.log(this.name);

    sessionStorage.setItem('inputdata', this.name)

  }
  checkboxx(event: any) {
    // console.log(this.selectopt.value.checkboxs);
    // console.log(event.target.checked);
    // console.log(event.target.value);
    if (event.target.checked === true) {
      console.log(event.target.checked);
      this.selectedcheckArr.push(event.target.value)
    }
    else if (event.target.checked === false) {
      console.log(event.target.checked);
      console.log(event.target.value);
      console.log(this.selectedcheckArr);
      console.log(this.selectedcheckArr.indexOf(event.target.value));

      const ind = this.selectedcheckArr.indexOf(event.target.value)
      this.selectedcheckArr.splice(ind, 1)
      console.log(this.selectedcheckArr);
    } else {
    }
    console.log(this.selectedcheckArr);

  }
}



