import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { timer } from 'rxjs';

@Component({
  selector: 'app-otp-demo',
  templateUrl: './otp-demo.component.html',
  styleUrls: ['./otp-demo.component.css']
})
export class OtpDemoComponent implements OnInit {

  otp = '';
  secs = 15;
  statusmsg = '';
  color: string | undefined;
  otpform: FormGroup;


  // @ViewChild('focus2') focus2!: ElementRef; 
  // @ViewChild('focus3') focus3!: ElementRef; 
  // @ViewChild('focus4') focus4!: ElementRef; 
  // @ViewChild('focus5') focus5!: ElementRef; 

  // @ViewChildren('input') nxtfocus!: QueryList<ElementRef> ;

  constructor(private http:HttpClient, private formbuilder: FormBuilder,private actroute:ActivatedRoute) {
    this.otpform = formbuilder.group({
      fst: [''],
      sec: [''],
      thrd: [''],
      frth: [''],
      fth: [''],

    })
  }
  Otpverify() {
    // console.log("submitted");
    // console.log(this.otpform.value);
    let verifyotp = this.otpform.value.fst + this.otpform.value.sec + this.otpform.value.thrd + this.otpform.value.frth + this.otpform.value.fth
    // console.log(verifyotp);
    // console.log(this.otp);
    if (verifyotp == this.otp) {
      this.statusmsg = 'OTP verified Successfully';
      this.color = 'green';
      // console.log('success');
    } else {
      this.statusmsg = 'Invalid OTP ';
      this.color = 'red';
      // console.log('wrong');

    }

  }

  ngOnInit(): void {
    
    // console.log(this.nxtfocus?.nativeElement.id);

  }
  Otpenerted() {



    if (this.secs <= 15 && this.secs > 0) {
      //  document.getElementById('rbtn').
      setTimeout(() => {

        this.time();
      }, 1000);
    }
    if (this.secs == 15) {


      this.otp = '';
      this.statusmsg = '';
      for (let i = 0; i < 5; i++) {
        this.otp = this.otp + Math.floor(Math.random() * 10);
      }

    }

  }
  time() {
    this.secs = this.secs - 1;

    this.Otpenerted()
    if (this.secs <= 0) {
      this.secs = 15;
    }

  }
  Fileupload(e:any){
    console.log(e.target.value);
    this.http.post('./Fils',e.target.value).subscribe(res=>{
      console.log(res,"res");
      
    })
    console.log(e.target.files[0]);

    
  }

  Nxtfield(e: any, val: number) {
    console.log(val);
    console.log(e.target.id);
    if (e.srcElement.maxLength === e.srcElement.value.length) {
      e.preventDefault();
      let nextControl: any = e.srcElement.nextElementSibling;
      // Searching for next similar control to set it focus
      while (true) {
        if (nextControl) {
          if (nextControl.type === e.srcElement.type) {
            nextControl.focus();
            return;
          }
          else {
            nextControl = nextControl.nextElementSibling;
          }
        }
        else {
          return;
        }
      }
    }
    // if (e.target.length = 1) {
    //  this`.focus${val}`.nativeElement.focus()
    //  console.log(this.focus.nativeElement);

    // this.nxtfocus.toArray()[val].nativeElement.focus();

    // this.nxtfocus?.nativeElement(val).focus()
    // document.getElementById(val)?.focus();
    //   }
    // }
  }
}


