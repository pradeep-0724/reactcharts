import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtpDemoComponent } from './otp-demo.component';

describe('OtpDemoComponent', () => {
  let component: OtpDemoComponent;
  let fixture: ComponentFixture<OtpDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtpDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OtpDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
