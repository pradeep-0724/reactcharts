import { HttpClient } from '@angular/common/http';
import { isNgTemplate } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
interface Datamodel{
  job_id:number,
  status:string,
  assigned_to:string[]
}
@Component({
  selector: 'app-zuper-home',
  templateUrl: './zuper-home.component.html',
  styleUrls: ['./zuper-home.component.css']
})

export class ZuperHomeComponent implements OnInit {
  assigned:string[]=[];
  constructor(private http: HttpClient,private rtr:Router) { }

  data:Datamodel[] = [
    {
      job_id: 1,
      status: 'CONFIRMED',
      assigned_to: ['raghav', 'vijay'],
    },
    {
      job_id: 2,
      status: 'ON_MY_WAY',
      assigned_to: ['vijay'],
    },
    {
      job_id: 3,
      status: 'CONFIRMED',
      assigned_to: ['ranjith'],
    },
    {
      job_id: 4,
      status: 'STARTED',
      assigned_to: ['raghav'],
    },
    {
      job_id: 5,
      status: 'STARTED',
      assigned_to: ['ranjith'],
    },
    {
      job_id: 6,
      status: 'COMPLETED',
      assigned_to: ['vijay'],
    },
  ];
  statusArr: string[] = [];
  contbyStsObj:{[key: string]: number}={};
  assignObj:any={};
  users:object[]=[];
  finalResult:any={}

  ngOnInit(): void {
    console.log('hihh');

    // this.http.get('https://pastebin.com/raw/xLYP4p5z').subscribe((ele:any)=>{
    //   console.log(ele);
    // })
   
//  count by status
 
    this.statusArr=[...new Set(this.data.map((ele)=>ele.status))]
    console.log(this.statusArr);

   
    this.statusArr.map((ele:any)=>{
      this.contbyStsObj[ele]=0
    })
    console.log(this.contbyStsObj);
    
    console.log(this.statusArr);
    this.data.map((ele)=>{
      this.statusArr.map((st)=>{
        if(ele.status===st){
          this.contbyStsObj[st]=this.contbyStsObj[st]+1
        }
      })
    })
    console.log(this.contbyStsObj);
    console.log([{...this.contbyStsObj}]);



    // assigned_to start from here
    this.data.map((ele)=>ele.assigned_to.map((item:any)=>this.assigned.push(item)))
    console.log(this.assigned);
    
    for(let i=0;i<this.assigned.length;i++){
      if(this.assignObj[this.assigned[i]]){
        this.assignObj[this.assigned[i]]+=1
      }
      else{
        this.assignObj[this.assigned[i]]=1
      }
    }
    console.log(this.assignObj);
    let user=[];
    for(let item in this.assignObj){
      console.log(this.assignObj[item]);
      this.users.push({
        'name':item,
        'count':this.assignObj[item]
      })      
      
    }
    console.log(this.users);
    this.finalResult={
      'count_by_status':this.contbyStsObj,
      'count_byy_user':this.users
    }
    console.log("final Result",this.finalResult);
    
    
    
  }
  jobHandler(item:string){
    console.log(item);
    this.rtr.navigate([`zuperjobs/${item}`])
    
  }

}
