import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ZuperHomeComponent } from './zuper-home.component';

describe('ZuperHomeComponent', () => {
  let component: ZuperHomeComponent;
  let fixture: ComponentFixture<ZuperHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ZuperHomeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ZuperHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
