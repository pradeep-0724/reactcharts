import { HttpClient } from '@angular/common/http';
import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import {FormGroup,FormControl,FormBuilder, Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
// import { loginFun } from '../store/action/actions';
import { UsersService } from '../UsersSrv/users.service';
@Component({
  selector: 'app-checkout',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class CheckoutComponent implements OnInit {
  checkoutForm:  FormGroup |any;
  storedata:any;
  checkform=[]
  jsondata:any;
  formdata:any[]=[]
  constructor(  private store:Store<{data:{email:string,password:string}}>,
    private formbuilder: FormBuilder,private rte:Router,private userserv:UsersService,private http:HttpClient) { 
   this.checkoutForm=formbuilder.group({
     email:['',[Validators.required, Validators.minLength(5)]],
     password:['',[Validators.required,Validators.minLength(3)]],
    
    
   });
  }
  Forgotpswd(){
    const email=prompt('enter email');
    const pswd=prompt('enter new password');
    let password={
      "password":pswd
    }
    for(let ele of this.formdata){
      if(ele.email===email){
        this.http.patch<any>(`http://localhost:3000/formdata/${ele.id}`,password).subscribe(res=>{
          console.log(res);
          
        })
      }
    }

  }

  details(){

    // this.store.dispatch(loginFun({value1:this.checkoutForm.value.email,value2:this.checkoutForm.value.password}))
    console.log("hi");
    console.log(this.checkoutForm.value);
    console.log(this.checkoutForm);
    
this.http.get<any>('http://localhost:3000/formdata').subscribe(res=>{
  console.log(res);
  
})
  this.rte.navigate(['views'])
  // localStorage.setItem('check',JSON.stringify(this.checkoutForm.value))
    
    
  }
 

  
  ngOnInit(): void {
    this.http.get<any>('http://localhost:3000/formdata').subscribe(res => {
      this.formdata = res
      console.log(this.formdata);

    })
   
    
  }
getdata(){
  console.log("getdata");
  
}
signup(){
  this.rte.navigate(['register'])
}
 
}
